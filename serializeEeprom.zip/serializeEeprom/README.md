# serializeEeprom
Arduino Library
ESP8266 Serialize structure (or class) to/from EEPROM
ESP32 support (using ncv)

Installation
------------
Download the ZIP archive (<https://github.com/microentropie/Arduino-Libraries/serializeEeprom.zip>)
open the Arduino IDE and choose Sketch -> Include Library -> Add .ZIP Library... and select the downloaded file.
