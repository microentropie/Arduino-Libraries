#ifndef _E_SERIES_COMMON_H_
#define _E_SERIES_COMMON_H_

#define EseriesBufSize 5

#endif //_E_SERIES_COMMON_H_
