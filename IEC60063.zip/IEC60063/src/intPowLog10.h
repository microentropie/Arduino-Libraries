#ifndef _INTPOWLOG10_H_
#define _INTPOWLOG10_H_

extern float pow10(int y);
extern int log10(float f);

#endif //_INTPOWLOG10_H_
