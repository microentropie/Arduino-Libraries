#ifndef _POW10_H_
#define _POW10_H_

extern float pow10(int y);

#endif //_POW10_H_
