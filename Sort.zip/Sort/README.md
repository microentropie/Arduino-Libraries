# Sort
Arduino Library
Sort an array of objects using the specified compare method

Installation
------------
Download the ZIP archive (<https://github.com/microentropie/Arduino-Libraries/Sort.zip>)
open the Arduino IDE and choose Sketch -> Include Library -> Add .ZIP Library... and select the downloaded file.
