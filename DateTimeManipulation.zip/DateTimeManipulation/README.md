# DateTimeManipulation
Arduino Library
Date and Time manipulation routines

Installation
------------
Download the ZIP archive (<https://github.com/microentropie/Arduino-Libraries/DateTimeManipulation.zip>)
open the Arduino IDE and choose Sketch -> Include Library -> Add .ZIP Library... and select the downloaded file.
